const config = {};

config.lt = {
	url: "https://gateway-lon.watsonplatform.net/language-translator/api",
	iam_apikey: "qumMdrzpatRkCt8G66_BJtErqfOX1ARJEcMrrrxz6YLP",
	version: "2018-05-01",
};

config.port = 8080;

module.exports = {
	config
};
