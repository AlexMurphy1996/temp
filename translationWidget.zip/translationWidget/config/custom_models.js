/*

Supported base models you can find here:
https://console.bluemix.net/docs/services/language-translator/translation-models.html#translation-models

Values are case sensitive.

Skill definition:
const models = {
  <TRANSLATION BASE MODEL>: {
    "custom_model": <ID OF CUSTOM MODEL>
  },
  ...
}

E.g. for custom model of translation service based on English to French model (en-fr):
const skills = {
  "en-fr": {
    "custom_model": "35df8edd-5781-4f63-867f-ab3bc1b06004"
  },
  ...
}
*/

const models = {
  "en-es": {
    "custom_model": "ede080b5-a067-468a-81e8-09e10981efbd"
  },
  "en-ro": {
    "custom_model": "e34f6a66-b843-4e52-b718-3ba61cab389b"
  },
  "en-pt": {
    "custom_model": "6deb75a9-77c2-484b-b1a2-8b883dfb1fe2"
  },
  "en-it": {
    "custom_model": "161a32e3-6864-4ce9-a7c7-cd21df7d5499"
  },
  "en-de": {
    "custom_model": "e0dc818a-e228-4ecb-a1f9-adead0125535"
  },
  "en-da": {
    "custom_model": "6f442b8d-eeac-4223-9360-39fe1ba564ff"
  },
  "en-ru": {
    "custom_model": "5c93c5cb-c9ad-466a-b67b-50bd48f53691"
  },
  "en-sv": {
    "custom_model": "4c722c6a-6f8d-4023-bd41-969dcf4f5554"
  }
}

module.exports = {
  models
};

module.exports = {
  models
};