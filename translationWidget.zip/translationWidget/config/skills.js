/*

WARNING: The lanugage model (translation) has to be supported in both ways!

Supported models you can find here:
https://console.bluemix.net/docs/services/language-translator/translation-models.html#translation-models

Values are case sensitive.

Skill definition:
const skills = {
  <NAME OF LP ENGAGEMENT SKILL>: {
    "from": <SOURCE LANUAGE>,
    "to": <TARGET LANUAGE>
  },
  ...
}

E.g. for translation of client messages from Russian to English and for agent messages from English to Russian:
const skills = {
  "Russian": {
    "from": "ru",
    "to": "en"
  },
  ...
}

*/

const skills = {
  "BF German Logged Out": {
    "from": "de",
    "to": "en"
  },
  "BF German Logged Out OOH": {
    "from": "de",
    "to": "en"
  },
  "BF Portuguese Logged Out": {
    "from": "pt",
    "to": "en"
  },
  "BF Portuguese Logged Out OOH": {
    "from": "pt",
    "to": "en"
  },
  "BF Russian Logged Out": {
    "from": "ru",
    "to": "en"
  },
  "BF Russian Logged Out OOH": {
    "from": "ru",
    "to": "en"
  },
  "BF Swedish Logged Out": {
    "from": "sv",
    "to": "en"
  },
  "BF Swedish Logged Out OOH": {
    "from": "sv",
    "to": "en"
  },
  "BF Danish Logged Out": {
    "from": "da",
    "to": "en"
  },
  "BF Danish Logged Out OOH": {
    "from": "da",
    "to": "en"
  },
  "BF Spanish Logged Out": {
    "from": "es",
    "to": "en"
  },
  "BF Spanish Logged Out OOH": {
    "from": "es",
    "to": "en"
  },
  "BF Italian Logged Out": {
    "from": "it",
    "to": "en"
  },
  "BF Italian Logged Out OOH": {
    "from": "it",
    "to": "en"
  },
  "BF German": {
    "from": "de",
    "to": "en"
  },
  "BF German OOH": {
    "from": "de",
    "to": "en"
  },
  "BF Portuguese": {
    "from": "pt",
    "to": "en"
  },
  "BF Portuguese OOH": {
    "from": "pt",
    "to": "en"
  },
  "BF Russian": {
    "from": "ru",
    "to": "en"
  },
  "BF Russian OOH": {
    "from": "ru",
    "to": "en"
  },
  "BF Swedish": {
    "from": "sv",
    "to": "en"
  },
  "BF Swedish OOH": {
    "from": "sv",
    "to": "en"
  },
  "BF Danish": {
    "from": "da",
    "to": "en"
  },
  "BF Danish OOH": {
    "from": "da",
    "to": "en"
  },
  "BF Spanish": {
    "from": "es",
    "to": "en"
  },
  "BF Spanish OOH": {
    "from": "es",
    "to": "en"
  },
  "BF Italian": {
    "from": "it",
    "to": "en"
  },
  "BF Italian OOH": {
    "from": "it",
    "to": "en"
  },
  "BF German VIP": {
    "from": "de",
    "to": "en"
  },
  "BF German VIP OOH": {
    "from": "de",
    "to": "en"
  },
  "BF Portuguese VIP": {
    "from": "pt",
    "to": "en"
  },
  "BF Portuguese VIP OOH": {
    "from": "pt",
    "to": "en"
  },
  "BF Russian VIP": {
    "from": "ru",
    "to": "en"
  },
  "BF Russian VIP OOH": {
    "from": "ru",
    "to": "en"
  },
  "BF Swedish VIP": {
    "from": "sv",
    "to": "en"
  },
  "BF Swedish VIP OOH": {
    "from": "sv",
    "to": "en"
  },
  "BF Italian VIP": {
    "from": "it",
    "to": "en"
  },
  "BF Italian VIP OOH": {
    "from": "it",
    "to": "en"
  },
  "BF Danish VIP": {
    "from": "da",
    "to": "en"
  },
  "BF Danish VIP OOH": {
    "from": "da",
    "to": "en"
  },
  "BF Spanish VIP": {
    "from": "es",
    "to": "en"
  },
  "BF Spanish VIP OOH": {
    "from": "es",
    "to": "en"
  },
  "BF Translation Portuguese": {
    "from": "pt",
    "to": "en"
  },
  "BF Translation Italian": {
    "from": "it",
    "to": "en"
  },
  "BF Translation Romanian": {
    "from": "ro",
    "to": "en"
  },
  "BF Translation Spanish": {
    "from": "es",
    "to": "en"
  },
  "BF Translation Danish": {
    "from": "da",
    "to": "en"
  },
  "BF Translation German": {
    "from": "de",
    "to": "en"
  },
  "BF Translation Russian": {
    "from": "ru",
    "to": "en"
  },
  "BF Translation Spanish Latam": {
    "from": "es",
    "to": "en"
  },
}

module.exports = {
  skills
};