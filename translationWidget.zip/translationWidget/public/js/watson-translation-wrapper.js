function translate(from, to, text, onProgress, onError, onComplete) {
	onProgress();

  var options = {
    from: from,
    to: to,
    text: text
  }

  if(validateRequest(options)){
    if(options.from == options.to)
      onComplete(text);

    $.post('/api/translate',
      options,
      function (data, status, xhr) {
        if(status == "success")
          onComplete(data);
        else
          onError(data);
      }
    )
  } else {
    console.log(options)
    onError("Validation failed");
  }
};

function language(skill, loadLanguages) {
  onProgress();
  $.post(
    '/api/languageBySkill',
    {
      skill
    },
    function (data, status, xhr) {
      if(status == "success")
        loadLanguages(data);
      else
        console.log(data);
    }
  )
};

//all fields should be filled
function validateRequest(options){
  return options.to && options.from && options.text;
}