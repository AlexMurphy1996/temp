const assert = require('assert');
const chai = require('chai');
let server = require('../server');
let chaiHttp = require('chai-http');
let should = chai.should();

chai.use(chaiHttp);

process.env.NODE_ENV = 'test';

describe('Array', function() {
	describe('#indexOf()', function() {
		it('should return -1 when the value is not present', function() {
			assert.equal([1, 2, 3].indexOf(4), -1);
		});
	});
});

describe('API Calls', () => {
	/*
	* Test the /POST Translation API call
	*/
	describe('/POST Translation', () => {
		it('it should make translation', (done) => {
			let correctObjectToTranlsate = {
				text: "Hello, my name is Watson",
				from: "en",
				to: "es"
			}
			chai.request(server)
				.post('/api/translate')
				.send(correctObjectToTranlsate)
				.end((err, res) => {
					if (err) {
            done(err);
          } else {
          	res.should.have.status(200);
						res.text.should.be.a('string');
            done();
          }
			});
		});

		it('it should not make translation - without "to" field', (done) => {
			let objectWithoutToFieldToTranlsate = {
				text: "Hello, my name is Watson",
				from: "en",
			}
			chai.request(server)
				.post('/api/translate')
				.send(objectWithoutToFieldToTranlsate)
				.end((err, res) => {
					if (err) {
            done(err);
          } else {
          	res.should.have.status(500);
						res.text.should.be.a('string');
						res.text.should.include('target');
						done();
          }
			});
		});

		it('it should not make translation - without "from" field', (done) => {
			let objectWithoutFromFieldToTranlsate = {
				text: "Hello, my name is Watson",
				to: "es"
			}
			chai.request(server)
				.post('/api/translate')
				.send(objectWithoutFromFieldToTranlsate)
				.end((err, res) => {
					if (err) {
            done(err);
          } else {
          	res.should.have.status(500);
						res.text.should.be.a('string');
						res.text.should.include('source');
						done();
          }
			});
		});

		it('it should not make translation - without "text" field', (done) => {
			let objectWithoutTextFieldToTranlsate = {
				from: "en",
				to: "es"
			}
			chai.request(server)
				.post('/api/translate')
				.send(objectWithoutTextFieldToTranlsate)
				.end((err, res) => {
					if (err) {
            done(err);
          } else {
          	res.should.have.status(500);
						res.text.should.be.a('string');
						res.text.should.include('text');
						done();
          }
			});
		});

	});
});