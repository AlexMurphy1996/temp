const LanguageTranslatorV3 = require("watson-developer-cloud/language-translator/v3");
const config = require('../config/config').config;
const customModels = require("../config/custom_models").models;
const languageTranslator = new LanguageTranslatorV3(config.lt);

let translate = function (text, from, to, callback) {
  let model = from + '-' + to;

  if(customModels[model])
    model = customModels[model].custom_model;

  languageTranslator.translate({
  	text: text,
    model_id: model
  }, function (error, response) {
  	callback(error, response);
	});
}

let listLanguages = function (callback) {
  languageTranslator.listModels({},
  function(error, response) {
      callback(error, response);
  });

}


module.exports = {
  translate,
  listLanguages
};