const express = require("express");
const router = express.Router()
const languageTranslation = require("../services/language-translation")
const skills = require("../config/skills").skills;

router.post("/translate", function (req, res) {
	let text = req.body.text;
	let sourceLanguage = req.body.from;
	let targetLanguage = req.body.to;
	languageTranslation.translate(text, sourceLanguage, targetLanguage, function (error, response) {
	  	if (error) {
	  	  console.error(error);
	  	  res.status(500).send("Something went wrong. " + error)
	  	} else {
	  		res.status(200).send(response.translations[0].translation)
	  	}
	});
});

router.post("/languageBySkill", function (req, res) {
	let skill = req.body.skill;

	let skillObject = skills[skill];

	console.log(skillObject)

	languageTranslation.listLanguages(function (error, response) {
		if (error) {
			console.error(error);
	 	  res.status(500).send("Something went wrong. " + error)
	 	} else {
			if(!skillObject)
				return res.status(200).send({ skillFound: false, languages: response })

			let from = skills[skill].from;
			let to = skills[skill].to;

	 		res.status(200).send({ skillFound: true, from, to, languages: response });
	 	}
	});
});

module.exports = router;